##########################
### Catgirl Downloader ###
##########################

This is a windows-only version of Catgirl Downloader by Nyarch Linux. https://github.com/NyarchLinux/CatgirlDownloader
This program requires Python to run. Download it here: https://www.python.org/downloads/