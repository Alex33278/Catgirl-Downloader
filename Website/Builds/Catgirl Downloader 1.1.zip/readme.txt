##########################
### Catgirl Downloader ###
##########################

This program requires Python to run. Download it here: https://www.python.org/downloads/